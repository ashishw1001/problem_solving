package hack_infy;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class rsa {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the msg to incrypt and decrypt");
        int msg=12;
        System.out.println("Enter value of p :");
        int p=7;
        System.out.println("Enter value of q :");
        int q=17;

        int n=p*q;
        int z=(p-1)*(q-1);
        System.out.println("z is "+z);
        int e;
        for(e=2;e<=z;e++){
            if(gcd(e,z)==1)break;
        }
        System.out.println("Public key is :"+e);
        int d=0;
        for(int i=0;i<=9;i++){
            int x=1+i*z;
            if(x%e==0){
                d=x/e;
                break;
            }
        }
        System.out.println("Private key is :"+d);
        double c=Math.pow(msg,e)%n;
        System.out.println("Encrypted msg :"+c);
        BigInteger C= BigDecimal.valueOf(c).toBigInteger();
        BigInteger N=BigInteger.valueOf(n);
        System.out.println("Decrypted msg "+C.pow(d).mod(N));




    }
    static int gcd(int e, int z)
    {
        if (e == 0)
            return z;
        else
            return gcd(z % e, e);
    }
}
