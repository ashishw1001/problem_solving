package hack_infy;

import java.util.List;
import java.util.Scanner;

public class rohit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       int n=sc.nextInt();
       int[]arr=new int[n];
       for(int i=0;i<n;i++){
           arr[i]=sc.nextInt();
        }
       int []ans=getNegativeFirst(arr);
       for(int i:ans){
           System.out.println(i);
       }
    }
    public static int[] getNegativeFirst(int[]arr) {
        int key, j;
        for (int i = 1; i < arr.length; i++) {
            key = arr[i];
            if (key > 0)
                continue;
            j = i - 1;
            while (j >= 0 && arr[j] > 0) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
        return arr;
    }
}
