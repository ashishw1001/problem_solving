package hack_infy;

import java.util.ArrayList;
import java.util.Scanner;
import  java.util.*;
public class house_graph {
    static void addEdge(ArrayList<ArrayList<Integer> > adj, int u, int v)
    {
        adj.get(u).add(v);
        adj.get(v).add(u);
    }
   public static  int dearngeenttree(int M,ArrayList<ArrayList<Integer>>Edeges){
        int ans=0;
       ArrayList<ArrayList<Integer> > adj = new ArrayList<ArrayList<Integer> >(M);
       for (int i = 0; i < M; i++)
           adj.add(new ArrayList<Integer>());
       for(int i=0;i<M;i++){
           adj.get(i).add(Edeges.get(i).get(0));
           adj.get(i).add(Edeges.get(i).get(1));
       }

        return ans;
    }
    public static void main(String[] args)
    {

    }
}
