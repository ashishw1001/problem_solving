package hack_infy;
public class CarModel {
    private String licenceNumber,model;
    private double currentMileage;
    private int engineSize;

    public String getLicenceNumber() {
        return licenceNumber;
    }
    public void setLicenceNumber(String licenceNumber) {
        this.licenceNumber = licenceNumber;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public double getCurrentMileage() {
        return currentMileage;
    }
    public void setCurrentMileage(double currentMileage) {
        this.currentMileage = currentMileage;
    }
    public int getEngineSize() {
        return engineSize;
    }
    public void setEngineSize(int engineSize) {
        this.engineSize = engineSize;
    }

}



