package hack_infy;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.*;

public class chinmay1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        List<String> list = new ArrayList<>();
        sc.nextLine();
        for (int i = 0; i < n; i++) {
            list.add(sc.nextLine());
        }
        System.out.println(langestpalindrome(n, m, list));
    }
    public static int langestpalindrome(int n, int m, List<String> s) {
        String[] array = s.toArray(new String[s.size()]);
        return  max_len(array,n,m);
    }
    static String reverse(String input)
    {
        char[] a = input.toCharArray();
        int l, r = a.length - 1;
        for (l = 0; l < r; l++, r--)
        {
            char temp = a[l];
            a[l] = a[r];
            a[r] = temp;
        }
        return String.valueOf(a);
    }
    static int max_len(String s[],int N, int M)
    { HashSet<String> set_str = new HashSet<>();
        for (int i = 0; i < N; i++)
        {
            set_str.add(s[i]);
        }
        Vector<String> left_ans =new Vector<>();
        Vector<String> right_ans = new Vector<>();
        String mid = "";
        for (int i = 0; i < N; i++)
        {
            String t = s[i];
            t = reverse(t);
            if (t == s[i])
            {
                mid = t;
            }
            else if (set_str.contains(t))
            {
                left_ans.add(s[i]);
                right_ans.add(t);
                set_str.remove(s[i]);
                set_str.remove(t);
            }
        }
        String ans="";
        for (String x : left_ans)
        {
            ans=ans+x;
        }
        ans=ans+mid;
        Collections.reverse(right_ans);
        for (String x : right_ans)
        {
            ans=ans+x;
        }
        return ans.length();
    }
}

