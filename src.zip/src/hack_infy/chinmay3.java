package hack_infy;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;
public class chinmay3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        List<Integer>list=new ArrayList<>();
        int k=sc.nextInt();
        for(int i=0;i<n;i++){
            list.add(sc.nextInt());
        }
        System.out.println(solve(n,k,list));
    }
    public static int solve(int n,int k,List<Integer>l){
        if(n<=k)return 1;
        TreeMap<Integer, Integer> tmap = new TreeMap<Integer, Integer>();
        for (Integer t : l) {
            Integer c = tmap.get(t);
            tmap.put(t, (c == null) ? 1 : c + 1);
        }
        List<Integer> list=new ArrayList<>();
        for (Map.Entry m : tmap.entrySet())
           list.add((int)m.getValue());
        Collections.sort(list);
        for(int i=1;i<=k;i++){
            for(int j=0;j<list.size();j++){
                if(list.get(j)>0){
                    list.set(j,list.get(j)-1);
                    break;
                }
            }
        }
        int ans=0;
        for(int i:list){
            if(i>0)ans++;
        }
        return ans;

    }
}
