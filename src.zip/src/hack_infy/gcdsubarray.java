package hack_infy;

import java.util.List;
import java.util.Scanner;
import  java.util.*;

public class gcdsubarray {
    public  static List<Integer>list=new ArrayList<Integer>();
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int []arr=new int[n];

        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        list.add(1);
         findlength(arr,0,arr.length);
        Collections.sort(list);
        System.out.println(list.get(list.size()-1));
    }
    public static void findlength(int[]arr,int st,int ed){
        if(!(st<=ed)||ed<0||st>=arr.length)return;
        if(findGCD(arr,st,ed)>=(ed-st)) list.add(ed-st);
        findlength(arr,st+1,ed);
        findlength(arr,st,ed-1);
        findlength(arr,st+1,ed-1);
    }


    static int gcd(int a, int b)
    {
        if (a == 0)
            return b;
        return gcd(b % a, a);
    }
    static int findGCD(int arr[], int st,int ed)
    {
        int result = arr[st];
        for(int i=st;i<ed;i++){
            int element=arr[i];
            result = gcd(result, element);
            if(result == 1)
            {
                return 1;
            }
        }
        return result;
    }
}
