package hack_infy;

import java.util.*;

public class arrayreptedfirst {
    public static void main(String[] args) {
//        int []arr={2,3,4,4,5,3,2,7};
//        HashMap<Integer,Integer> map=new HashMap<>();
//        for(int i:arr){+++
//            if(map.containsKey(i)){
//                map.put(i,map.get(i)+1);
//            }
//            else map.put(i,1);
//        }
//        for(Map.Entry<Integer,Integer> me :map.entrySet()){
//            if(me.getValue()>=2){
//                System.out.println(me.getKey());
//                break;
//            }
//        }


//
//        int []arr={2,3,4,4,5,3,2,7};
//        int firstvalue=-1;
//        boolean flag=true;
//        for(int i=0;i<arr.length;i++){
//            firstvalue=arr[i];
//            for(int j=arr.length-1;j>=0;j--) {
//                if (firstvalue == arr[j]) {
//                    System.out.println(arr[j]);
//                    flag=false;
//                    break;
//                }
//            }
//            if(!flag)break;
//        }



//     Integer []arr={2,3,4,4,5,3,2,7};
//        System.out.println(arr[0]/5);
//        for(int i=0;i<arr.length;i++){
//            Set<Integer> set=new HashSet<>();
//            for(int j=i+1;j<arr.length;j++){
//                set.add(arr[j]);
//            }
//            if(set.contains(arr[i])){
//                System.out.println(arr[i]);
//                break;
//            }
//        }







        int[] arr= {12,3,5,1,9};
        Arrays.sort(arr);
        int start=0;
        int end=arr.length-1;
        while(start<end){
            if(arr[start]+arr[end]==10){
                System.out.println(arr[start]+" "+arr[end]);
                System.out.println(true);
                break;
            }
            if(arr[start]+arr[end]>10){
                end--;
            }
            else{
                start++;
            }
        }

    }
}
