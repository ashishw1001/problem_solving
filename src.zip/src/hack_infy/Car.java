package hack_infy;
import java.util.*;
public class Car {
    public  static void findCarList(double currentMileage,int currentengineSize,CarModel[]carr){
        boolean flag=false;
        for(int i=0;i<carr.length;i++){
            if(carr[i].getEngineSize()>currentengineSize &&carr[i].getCurrentMileage()>currentMileage) {
                flag=true;
                System.out.format("%10s %12s %15.2f %10d",carr[i].getLicenceNumber(), carr[i].getModel(), carr[i].getCurrentMileage(), carr[i].getEngineSize());
                System.out.println();
            }
        }
        if(!flag){
            System.out.println("No cars Found");
        }

    }
}
