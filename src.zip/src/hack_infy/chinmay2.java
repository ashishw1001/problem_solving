package hack_infy;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.*;

public class chinmay2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int k=sc.nextInt();
        int m=sc.nextInt();
        List<Integer> list=new ArrayList<>();
        for(int i=0;i<k;i++){
            list.add(sc.nextInt());
        }
        System.out.println(list);
        System.out.println(solve(n,k,m,list));

    }
    public  static  int solve(int n,int k,int m,List<Integer>t){
        if((k+1)*n<=m)return (k+1)*n;
        Collections.sort(t);
        int ans=0;
        int p=0;
        while(m>0){
            if(t.get(p)*n<m){
                ans=ans+n;
                m=m-t.get(p)*n;
                ans++;
                p++;
            }
            else{
                ans++;
                m=m-t.get(p);
                p++;
            }
            if(p==t.size()){
                ans++;
                break;
            }
        }
        return ans;
    }

}
