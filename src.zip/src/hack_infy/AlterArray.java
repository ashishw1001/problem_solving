package hack_infy;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AlterArray {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int m=sc.nextInt();
        List<Integer>X=new ArrayList<>();
        for(int i=0;i<m;i++){
                X.add(sc.nextInt());
        }
        System.out.println(solve(m,X));
    }
    public static int solve(int m,List<Integer>X){
        int ans=0;
        int pow=1;
        if(m==1) return X.get(0)*10;
        if(m%2==0) {
            for (int i = 0; i <(m / 2); i++) {
                ans = ans + (X.get(m - i - 1) * (int) Math.pow(10, pow++)) % 1000000007;
                ans = ans + (X.get(i) * (int) Math.pow(10, pow++)) % 1000000007;

            }
        }
        else{
            for (int i = 0; i <= (m / 2); i++) {
                if(i<=m/2-1)   ans = ans + (X.get(m - i - 1) * (int) Math.pow(10, pow++)) % 1000000007;
                ans = ans + (X.get(i) * (int) Math.pow(10, pow++)) % 1000000007;
            }

        }

        return ans%1000000007;
    }
}
