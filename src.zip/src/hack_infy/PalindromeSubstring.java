package hack_infy;
import java.util.*;
public class PalindromeSubstring {
        public  static int palindromeStrings(String str){
            String temp = "";
            StringBuffer stf;
            int count = 0;
            for (int i = 0; i < str.length(); i++) {;
                for (int j = i ; j <= str.length(); j++) {
                    temp = str.substring(i, j);
                    if (temp.length() >= 2) {
                        stf = new StringBuffer(temp);
                        stf.reverse();
                        if (stf.toString().compareTo(temp) == 0)
                            count++;
                    }
                }
            }
            return count;
        }

        // Driver Code
        public static void main(String args[]) throws Exception {
            // Declare and initialize the string
            String str = "abbaeae";
            // Call the method
            System.out.println((str));
        }
}

