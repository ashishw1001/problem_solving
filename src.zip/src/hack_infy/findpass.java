package hack_infy;

import java.util.Scanner;
import java.util.*;
public class findpass {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        List<String>A=new ArrayList<>();
        sc.nextLine();
        for(int i=0;i<n;i++){
            A.add(sc.nextLine());
        }
        String pass=sc.nextLine();
        int k=sc.nextInt();
        System.out.println(findpass(n,A,pass,k));
    }

    public static List<Integer> findpass(int n,List<String>A,String passwd,int k){
        int time=0;
        A.sort((s1, s2) -> Math.abs(s1.length() - "intelligent".length()) - Math.abs(s2.length() - "intelligent".length()));
        Collections.reverse(A);
        List<Integer> list=new ArrayList<>();
        int c=0;
        for(String i:A){
            if(i.length()< passwd.length())c++;
        }
        int cg=0;
        for(String i:A){
            if(i.length()<= passwd.length())cg++;
        }
        System.out.println(c+" "+cg);
        list.add(c/k*5+c+1);
        list.add(((cg-1)/k)*5+cg);
        Collections.sort(list);
       return list;
    }

}
