package hack_infy;

import java.util.Scanner;

public class minimumfold {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int h=sc.nextInt();
        int w=sc.nextInt();
        int h1=sc.nextInt();
        int w1=sc.nextInt();
        int hd=h-h1;
        int wd=w-w1;
        int c=0;
        while(hd!=0){
            hd=hd-h;
            c++;
        }
        while (wd!=0){
            wd=wd-w;
            c++;
        }
        System.out.println(c);
    }
}
