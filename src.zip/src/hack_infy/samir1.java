package hack_infy;

import java.util.Scanner;

public class samir1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        long arr[]=new long[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
    }
    long []solution(int q,long[]arr){
        long[] ans=new long[arr.length];
        for(int i=0;i<arr.length;i++){
            if(arr[i]<5)ans[i]=0;
            else ans[i]=findNumberOfStrings(arr[i]);
        }
        return ans;
    }
    public  static long findNumberOfStrings(long n)
    {
        return (n+1)*(n+2)*(n+3)*(n+4)/24;
    }
}
