package hack_infy;

import java.util.Scanner;

public class baseconversion {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        while(t-->0){
            int n=sc.nextInt();
            int c=0;
            for(int i=0;i<=36;i++){
                if(baseConversion(Integer.toString(n),10,i).charAt(0)=='1')c++;
            }
            System.out.println(c);
        }
    }
    public static  String baseConversion(String number, int sBase, int dBase)
    {
        return Integer.toString(Integer.parseInt(number, sBase), dBase);
    }
}
