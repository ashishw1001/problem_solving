package hack_infy;

import java.util.Arrays;
import java.util.Scanner;

public class lexiorder {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int m=sc.nextInt();
        int k=sc.nextInt();
        sc.nextLine();
        String s=sc.nextLine();
        s=lexi(s);
        System.out.println(s.substring(k*m,k*m+m));
    }
    public  static String lexi(String s){
        char []carr=s.toCharArray();
        Arrays.sort(carr);
        return new String(carr);
    }
}
