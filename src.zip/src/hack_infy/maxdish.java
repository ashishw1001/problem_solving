package hack_infy;

import java.util.*;

public class maxdish {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        while(t-->0){

            int n=sc.nextInt();
            int []arr=new int[n];
            for(int i=0;i<n;i++){
                arr[i]=sc.nextInt();
            }
            Set<Integer> s=new HashSet<Integer>();
            for(int i:arr){
                s.add(i);
            }

            List<Integer> list=new ArrayList<>();
            for(int i:s){
                list.add(maxrep(arr,i));
            }

            int m=0;
            int e=Integer.MIN_VALUE;
            for(int i=0;i<list.size();i++){
                if(list.get(i)>e){
                    e=i;
                    m=i;
                }
            }
            System.out.println(s);
            System.out.println(list);
            Integer[] ans= s.toArray(new Integer[s.size()]);

            System.out.println(ans[m]);
        }
    }
    public static int maxrep(int []arr,int n){
       int i=0;
       int c=0;
       while (i<arr.length){
           if(arr[i]==n){
               c++;
               i+=2;
           }
           i++;
       }
       return c;
    }
}
