package hack_infy;
import java.io.*; // for handling input/output
import java.util.*; // contains Collections framework

// don't change the name of this class
// you can add inner classes if needed
//public  class Main{
//    public static void main (String[] args) {
//        // Your code here
//        Scanner sc=new Scanner(System.in);
//        int n=sc.nextInt();
//        while(n-->0){
//            int num1=sc.nextInt();
//            int num2=sc.nextInt();
//            if((num1^num2)==0){
//                System.out.println("NO");
//            }
//            else{
//                System.out.println("YES");
//            }
//        }
//    }
//}

/********************************************************* */
import java.util.*;
//    public static int isformable (int a[], int n, int num)
//    {
//        int i = 0;
//        while (i < n)
//        {
//            if (num % a[i] == 0)
//                num = num / a[i];
//            else
//                i++;
//        }
//        if (num == 1)
//            return 1;
//        return 0;
//    }
//    public static void main (String[]args)
//    {
//        Scanner sc = new Scanner (System.in);
//        int num = 2, count = 0,position;
//        int n = sc.nextInt ();
//        int[] a = new int[n];
//        for (int i = 0; i < n; i++)
//            a[i] = sc.nextInt ();
//        position= sc.nextInt ();
//        while (count < position)
//        {
//            if (isformable (a, n, num)==1)
//                count++;
//            num++;
//        }
//        System.out.print (num - 1);
//    }
//    public static int count=0;
//    public static void sumSubsets(int set[], int n, int target)
//    {
//        int x[] = new int[set.length];
//        int j = set.length - 1;
//        while (n > 0) {
//            x[j] = n % 2;
//            n = n / 2;
//            j--;
//        }
//        int sum = 0;
//        for (int i = 0; i < set.length; i++)
//            if (x[i] == 1)
//                sum = sum + set[i];
//
//        System.out.println(sum);
//
//        if (sum == target)count++;
//    }

import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Scanner  sc=new Scanner(System.in);
        String s=sc.nextLine();
        if(s.length()%2!=0) {
            System.out.println("No");
        }
        else{
            String sb=s.substring(0,2);
            int i=2;
            while (i<s.length()){
                if(!s.substring(i,i+2).equals(sb)) {
                    System.out.println("No");
                    return;
                }
                i+=2;
            }
            System.out.println("Yes");
        }

    }
}