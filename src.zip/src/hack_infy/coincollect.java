package hack_infy;
import java.util.*;
import java.io.*;
import java.lang.*;
import static java.util.stream.Collectors.*;

public class coincollect {
    public static int solve(int N,List<List<Integer>> arr){
        int x,y,c=0;
        Map<Integer,Integer> mapx=new HashMap<Integer,Integer>();
        for(int i=0;i<arr.size();i++){
           if(mapx.containsKey(arr.get(i).get(0))){
               mapx.put(arr.get(i).get(0), mapx.get(i)+1);
           }
           else{
               mapx.put(arr.get(i).get(0),1);
           }
        }
        Map<Integer,Integer> mapy=new HashMap<Integer,Integer>();
        for(int i=0;i<arr.size();i++){
            if(mapy.containsKey(arr.get(i).get(1))){
                mapy.put(arr.get(i).get(1),mapy.get(i)+1);
            }
            else{
                mapy.put(arr.get(i).get(1),1);
            }
        }
        int maxxx=Collections.max(mapx.values());
        int maxxcount= mapx.get(maxxx);
        int maxyy=Collections.max(mapy.values());
        int maxycount= mapy.get(maxyy);
       int xz=maxxcount+maxycount;
       List<Integer>templist=new ArrayList<>();
       templist.add(maxxx);
       templist.add(maxyy);
       if(arr.contains(templist))
           xz--;
       return xz;

    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int     N=sc.nextInt();
        List<List<Integer>> Arr = new ArrayList<>(N);
        for(int i=0; i<N; i++) {
            List<Integer>li=new ArrayList<>();
            for(int j=0;j<2;j++)li.add(sc.nextInt());
            Arr.add(li);
        }
        int result = solve(N, Arr);
        System.out.println(result);
    }
}
