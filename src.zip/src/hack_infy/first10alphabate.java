package hack_infy;

import java.util.Scanner;

public class first10alphabate {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        char[]carr=s.toCharArray();
        int length=0;
        for(char c:carr){
            if(c>='a'&&'a'<='j')length++;
        }
        System.out.println(length*(length+1)/2);
    }
}
