package hack_infy;

import java.util.*;
import java.util.Scanner;

public class vaishnavi3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        List<Integer>list=new ArrayList<>(n);
        for(int i=0;i<n;i++){
            list.add(sc.nextInt());
        }
        System.out.println(getLSIS(n,list));
    }
    public static  int getLSIS(int n,List<Integer>Arr){
       // if(n<=2) return 2;
        int k=2;
        for(int i=0;i<n-2;i++){
            int m1=Math.max(Arr.get(i),Arr.get(i+1));
            int m2=Math.max(Arr.get(i+1),Arr.get(i+2));
            if(m1<=m2)k++;
        }
        return k;
    }
}
