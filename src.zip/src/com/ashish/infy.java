package com.ashish;
import java.util.Scanner;

public class infy {

        public static void main(String[] args) {
            // Implement your code here
            Scanner sc=new Scanner(System.in);
            int p=sc.nextInt();
            int r=sc.nextInt();
            int t=sc.nextInt();

            int i=(p*r*t)/100;
            System.out.println(i);
    }


}
