package com.ashish;

public class switch_Statement {
    public static void main(String[] args) {
        System.out.println("AUghoauho");
    }
}
