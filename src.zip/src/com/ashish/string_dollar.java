package com.ashish;

import java.util.Scanner;
import java.util.*;

public class string_dollar {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the string ");
        String s=sc.next();
        int count=1;
        String a=s.substring(0,2);
        for(int i=3;i<s.length()-1;i++){
            String b=s.substring(i,i+2);
            if(b.contains(a)){
                count=count+1;
            }
        }
        System.out.println("Number of dollaers :"+count);
    }
}
