package com.ashish;

public class statement {
    public static void main(String[] args) {
        int n=174;
        if(n>150){
            System.out.println(n);
            if(n>200){
                System.out.println("Number is greater than 200");
            }
            else{
                System.out.println("Number is smaller than 200");
            }
        }
        else if(n>100){
            System.out.println("Number is greater than 100");
        }
        else{
            System.out.println("number is smallert than 100");
        }
    }
}
