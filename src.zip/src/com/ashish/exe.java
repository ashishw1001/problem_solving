package com.ashish;

import javax.jws.soap.SOAPBinding;

public class exe {

    public static void main(String[] args) {
        try{

             int num=30;
            System.out.println("The dision of number is "+num/0);

        }
        catch (Exception e){

        }
    }
}
