package com.ashish;

public class wrapperclasses {


    public static void main(String[] args) {
        System.out.println("This is main method ");
        int a=50;
        Integer i=Integer.valueOf(a);
        System.out.println("Value of i is "+i);
        Integer b=39;
        System.out.println("Value of b is "+b);
    }
}
