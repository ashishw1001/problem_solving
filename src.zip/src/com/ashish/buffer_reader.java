package com.ashish;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class buffer_reader {
    public static void main(String[] args) throws  Exception{
        BufferedReader br=null;
        try {
            String a = "";
            br=  new BufferedReader(new InputStreamReader(System.in));
            a = br.readLine();
            br.close();
        }
        catch (IOException e) {

        }
        finally {
           br.close();
        }

    }
}
