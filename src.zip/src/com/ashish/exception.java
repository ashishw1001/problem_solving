package com.ashish;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.sql.SQLOutput;

public class exception {


    public static void main(String[] args) {
        int i=8;
        int j=8;
        int k=0;
        int arr[] = new int[4];
        try{
            k=j/i;
            for(int l=0; l<6; l++){
                arr[l]=l;
            }
        }
        catch(ArithmeticException e){
            System.out.println("Arithmatic exception");
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Arrrray index out of bound exception");
        }
        catch(RuntimeException e){

            System.out.println("This is runtime Exception  "+e);
        }
        finally {
            System.out.println("Finnally Block ... BYE....");

        }

    }
}
