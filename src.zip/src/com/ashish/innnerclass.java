package com.ashish;
interface phok{
    void show();
}
public class innnerclass {
    static  int i;
      public innnerclass(int i){
        this.i=i;
        System.out.println("Innerclass 1 "+i);
    }

    public void show(){}

    public static void main(String[] args) {
          phok p =()->System.out.println("Bro");
          p.show();
    }
};

