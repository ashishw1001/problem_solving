package com.ashish;

import java.util.SortedMap;
import java.util.Spliterator;

public class construct {
    int a;
    String name;
    construct(int a,String name){
     this.a=a;
     this.name=name;
    }
     construct(){
        this.a=13;
        this.name="w3454";
     }


    public static void main(String[] args) {
        System.out.println("This is main method..");
        construct c1=new construct();
        System.out.println(c1.a+" "+c1.name);
        construct c2=new construct(123,"Ashish");
        System.out.println(c2.a+"  "+c2.name);
    }

}
