package com.ashish;

public class demo2 {
    int a;
    String name;
    demo2(int a,String name){
        this.a=a;
        this.name=name;
    }
    demo2(demo2 d){
        this.a=d.a;
        this.name=d.name;
    }
    public static void main(String[] args) {
        System.out.println("This is copy constructor ");
    }
}
