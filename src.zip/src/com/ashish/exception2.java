package com.ashish;


public class exception2 {
        public static void main(String args[])
        {
            System.out.println("This is the main method...");
            try
            {  System.out.println("This is first try");
                try
                { System.out.println("This is Second try");
                    try
                    {	System.out.println("This is Third try");
                        int a1[] = new int[5];
                        int num = 30;
                        int a = 0;
                        a1[7]=25;
                        System.out.println("The division is:"+num/a);
                    }
                    catch(ArithmeticException e)
                    {
                        System.out.println("This is divide by 0 error");
                    }// inner catch
                    catch(ArrayIndexOutOfBoundsException e1)
                    {
                        System.out.println("Array Index Exception ");
                    }
                    System.out.println("Inside 2nd try block...");
                    System.out.println("The division is:"+10/0);
                }
                catch(ArithmeticException e)
                {
                    System.out.println("This is divide by 0 error");
                }//2nd try ends
                System.out.println("Inside 1st try block...");
            }// first try ends
            catch(ArrayIndexOutOfBoundsException e1)
            {
                System.out.println("Array Index Exception ");
            }
            catch(Exception e2)
            {
                System.out.println("This is error");
            }
        }
    }

