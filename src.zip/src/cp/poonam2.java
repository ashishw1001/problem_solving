package cp;
import  java.util.*;
public class poonam2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        String s2=sc.nextLine();
        char[] c1=s1.toCharArray();
        char[] c2=s2.toCharArray();
        int num=sc.nextInt();
        if(num>s2.length()){
            System.out.println(s1+s2);
            return;
        }
        String ans="";
        boolean flag=true;
        int p1=0;
        int p2=0;
        while(ans.length()<=(s1.length()+s2.length())){
            if(flag){
                ans=ans+func(s1,p1,num);
                p1=p1+num;
                flag=false;
            }
            else {
                ans = ans + func(s2, p2,num);
                p2=p2+num;
                flag = true;
            }
        }
        System.out.println(ans);


    }
    public static String func(String s,int i,int j){
        if(i>s.length()-1) return "";
        else{
            return s.substring(i,Math.min(i+j,s.length()));
        }
    }
}
