package cp;

import java.util.Scanner;

public class fout_digit_otp {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        String ans="";
        for(int i=1;i<s.length();i+=2){
            int n=s.charAt(i)-'0';
            ans=ans+n*n;
        }
        System.out.println(ans.substring(0,4));
    }
}
