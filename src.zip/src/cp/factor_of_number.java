package cp;
import java.util.Scanner;
public class factor_of_number {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line= sc.nextLine();
        String [] strarr=line.split(" ");
        int sum=0;
        for(String s:strarr){
            if(Character.isDigit(s.charAt(0))){
                sum=sum+(s.charAt(s.length()-1)-'0');
            }
        }
        if(sum==0){
            System.out.println(-1);
        }
       else if(isprime(sum)){
            System.out.println(sum);
        }
        else if(isprime(reverse(sum))){
            System.out.println(reverse(sum));
        }
       else{
           int rev=reverse(sum);
           System.out.println(cfact(rev));
        }
    }
    public  static  boolean isprime(int n){
        for(int i=2;i<Math.sqrt(n);i++){
            if(n%i==0) return  false;
        }
        return true;
    }
    public  static int reverse(int num){
        int  reversed = 0;
        while(num != 0) {
            int digit = num % 10;
            reversed = reversed * 10 + digit;
            num /= 10;
        }
        return  reversed;
    }
    public static int cfact(int num){
        int count=0;
        for(int i=1;i<=num;i++){
            if(num%i==0) count++;
        }
        return  count;
    }
}
