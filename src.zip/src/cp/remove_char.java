package cp;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class remove_char {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        int[]countnum=new int[10];
        int[]countchar=new int[58];
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(Character.isDigit(c)&&!(Character.isAlphabetic(c))){
                countnum[c-'0']++;
            }
            if(Character.isAlphabetic(c)&&!(Character.isDigit(c))){
                countchar[c-'A']++;
            }
        }
        int maxnum=0;
        for(int i:countnum){
            if(i>maxnum) maxnum=i;
        }
        int maxchar=0;
        for(int i:countchar){
            if(i>maxchar) maxchar=i;
        }
        int p=Math.abs(maxchar-maxnum);
        char del=s.charAt(p);
        List<Character> charList = new ArrayList<Character>();
        for (char c : s.toCharArray()) {
            charList.add(c);
        }
        removeAll(charList,del);
        for(int i=0;i<charList.size();i++) {
            if (charList.get(i) == ' ') {
                charList.remove(i);
                charList.add(i, '$');
            }
        }
        String word= new String();
        for(char c:charList){
            word= word+ c;
        }
        System.out.println(word);
    }
  public static   void removeAll(List<Character> list, Character element) {
        while (list.contains(element)) {
            list.remove(element);
        }
    }
}
