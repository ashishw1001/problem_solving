package cp;
import java.util.*;
public class winner
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String[] arr={"ABC","ACB","ABC","ACB","ACB"};
        String ans=win(arr);
        System.out.println(ans);
    }
    public static String win(String [] arr){
        char[]res=new char[arr[0].length()];
        int p=0;
        while(p<arr[0].length()){
            int []ascii=new int[26];
            for(int j=0;j<arr.length;j++){
                char c=arr[j].charAt(p);
                ascii[c-'A']++;
            }
            int max=Integer.MIN_VALUE;
            for(int ele:ascii){
                if(ele>max) max=ele;
            }
            int as=0;
            for(int k=0;k<26;k++){
                if(ascii[k]==max) as=k;
            }
            int val=as+65;
            char ans=(char)val;
            res[p]=ans;
            p++;
        }

        String fi=new String(res);
        return fi;
    }
}

