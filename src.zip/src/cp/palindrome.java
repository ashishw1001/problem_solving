package cp;

import java.util.Scanner;

public class palindrome {
    public static int reverse(int a) {
        int number = a, reverse = 0;
        while (number != 0) {
            int remainder = number % 10;
            reverse = reverse * 10 + remainder;
            number = number / 10;
        }
        return  reverse;
    }
    public static boolean pal(int n){
        return n==reverse(n);
}

public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        while(!pal(a)) {
            a=a+reverse(a);
        }
    System.out.println(a);
    System.out.println(Integer.toString(a).length());
        }
}
