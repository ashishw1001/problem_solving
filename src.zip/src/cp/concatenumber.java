package cp;

import java.util.Scanner;

public class concatenumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String line=sc.nextLine();
        String []carr=line.split(",");
        int pf=0,pe=0;
        int sum=0;
        for(int i=0;i<carr.length;i++){
            if(carr[i].charAt(0)=='5') pf=i;
            if(carr[i].charAt(0)=='8') pe=i;

        }
        String  s="";
        for(int i=0;i<carr.length;i++) {
            if (i < pf || i > pe) sum = sum + carr[i].charAt(0) - 48;
            else s=s+carr[i];
        }
        System.out.println((int)Integer.parseInt(s)+(int)sum);
    }
}
