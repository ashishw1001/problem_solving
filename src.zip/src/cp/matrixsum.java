package cp;
import java.util.*;
public  class matrixsum {
    public  static  void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rows = scanner.nextInt();
        scanner.nextLine();
        int[][] arr = new int[rows][];
        for (int i = 0; i < rows; ++i) {
            String line = scanner.nextLine();
            arr[i] = lineToIntArray(line);
        }
        ArrayList<Integer> sqrlist=new ArrayList<>();
        int sqaure=0;
        boolean flag=false;
        for(int i=0;i<rows;i++){
            if(flag) {
                for (int j = arr[i].length-1; j >=0; j--) {
                    sqaure=sqaure+arr[i][j];
                    if(isPerfectSquare(sqaure)){
                        sqrlist.add(sqaure);
                        sqaure=0;
                    }
                }
                flag=true;
            }
            else{
                for(int j=0;j<arr[i].length;j++){
                    sqaure=sqaure+arr[i][j];
                    if(isPerfectSquare(sqaure)){
                        sqrlist.add(sqaure);
                        sqaure=0;
                    }
                }
            }
        }
        Collections.sort(sqrlist);
        if(sqrlist.size()==0){
            System.out.println(-1);
        }
        else{
            System.out.println(sqrlist.get(sqrlist.size()-1));
        }
    }
    public static boolean isPerfectSquare(int x)
    {
        if (x >= 0) {
            int sr = (int) Math.sqrt(x);
            return ((sr * sr) == x);
        }
        return false;
    }
    public static int[] lineToIntArray(String line) {
        return Arrays.asList(line.split(",")).stream().mapToInt(Integer::parseInt).toArray();
    }

}
