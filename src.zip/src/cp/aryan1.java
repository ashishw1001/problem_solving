package cp;

import java.util.Scanner;

public class aryan1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        String[]strarr=str.split(",");
        String alpha= "abcdefghijklmnopqrstuvwxyz";
        int row=sc.nextInt();
        int[][]mat=new int[row][2];
        for(int i=0;i<row;i++){
            mat[i][0]=sc.nextInt();
            mat[i][1]=sc.nextInt();
        }
        for(int i=0;i<strarr.length;i++){
            int []subarr=mat[i];
            char []subchar=strarr[i].toCharArray();
            strarr[i]=chartostr(subchar,subchar[subarr[0]],alpha.charAt(subarr[1]));
        }
        int mincon=Integer.MAX_VALUE;
        for(String s :strarr){
             if(countcosnent(s)<mincon){
                 mincon=countcosnent(s);
             }
        }
        String ans="";
        for(String s:strarr){
            if(countcosnent(s)==mincon&&s.length()>ans.length()){
                ans=s;
            }
        }
        System.out.println(ans);
    }
    public  static String chartostr(char[] arr,char whichchange,char tochange){
          for(int i=0;i<arr.length;i++){
              if(arr[i]==whichchange){
                  arr[i]=tochange;
              }
          }
          return new String(arr);
    }
    public  static  int countcosnent(String s){
        int count=0;
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(!(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')) {
                count++;
            }
        }
        return  count;
    }
}
