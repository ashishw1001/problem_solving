package cp;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.util.Scanner;

public class mathstrexp {

    public static void main(String[] args) throws ScriptException {
        ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
        ScriptEngine scriptEngine = scriptEngineManager.getEngineByName("JavaScript");
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        Object ob = scriptEngine.eval(s);
        System.out.println(ob);
    }
}
