package cp;

import java.util.Scanner;

public class charrep_print {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        int []arr=new  int[26];
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(Character.isLowerCase(c)==true){
                arr[c-'a']++;
            }
            if(Character.isUpperCase(c)==true){
                arr[c-'A']++;
            }
        }
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(Character.isLowerCase(c)==true){
                System.out.print(c+"_"+arr[c-'a']+",");
            }
            if(Character.isUpperCase(c)==true){
                System.out.print(c+"_"+arr[c-'A']+",");
            }
        }

    }
}
