package cp;

import java.util.Scanner;

public class consecative_char {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String []str={"30012","250232","53201","3004355","124111"};

        String s1="";
        String s2="";
        int c=0;
         for(int i=0;i<str.length-1;i++){
             for(int j=i+1;j<str.length;j++){
                 int a=strcmp(str[i],str[j]);
                  if(a>c){
                     a=c;
                     s1=str[i];
                     s2=str[j];
                  }
             }
         }

         String  ans=s1+s2;
         if(ans.length()>0){
             System.out.println(ans);
         }
         else{
             System.out.println("-1");
         }
    }
    public  static  int strcmp(String s1,String s2){
        int[]arr1=new int[5];
        int[]arr2=new int[5];
        for(int i=0;i<s1.length();i++){
            arr1[s1.charAt(i)-'0']++;
        }
        for(int i=0;i<s2.length();i++){
            arr2[s2.charAt(i)-'0']++;
        }
        int ans=0;
        for(int i=0;i<5;i++){
            if(arr1[i]==arr2[i]&&arr1[1]>ans){
                ans=arr1[i];
            }
        }
        return  ans;
    }
}
