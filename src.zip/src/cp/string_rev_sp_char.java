package cp;
import java.util.Scanner;

public class string_rev_sp_char {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        char[]carr=s.toCharArray();
        char[]ans=new char[carr.length];
        for(int i=0;i<carr.length;i++){
            if(!Character.isDigit(s.charAt(i)) && !Character.isLetter(s.charAt(i)) && !Character.isWhitespace(s.charAt(i))){
                ans[i]=carr[i];
            }
        }
        int p=0;
        for(int i=carr.length-1;i>=0;i--){
            if(!(!Character.isDigit(s.charAt(i))&& !Character.isLetter(s.charAt(i)) && !Character.isWhitespace(s.charAt(i)))){
                while(ans[p]!='\u0000'){
                    p++;
                }
                ans[p] = carr[i];
                p++;
            }
        }
        System.out.println(new String(ans));

    }
}
