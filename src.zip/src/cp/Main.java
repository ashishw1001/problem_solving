package cp;
import collcetions.ArrayList;

import  java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        Set<Integer> list = new HashSet<>();
        int p = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c) == true) {
                list.add(c - 48);
            }
        }
        int[] arr = new int[list.size()];
        for (int i : list) {
            arr[p] = i;
            p++;
        }
        Arrays.sort(arr);
        int ele = arr[0];
        if (ele % 2 != 0) {
            for (int i = 1; i < arr.length; i++) {
                if (arr[i] % 2 == 0) {
                    arr[0] = arr[i];
                    arr[i] = ele;
                    break;
                }
            }
        }
        if (arr[0] % 2 != 0) System.out.println(-1);
        else {
            for (int i = arr.length - 1; i >= 0; i--) {
                System.out.print(arr[i]);
            }
        }
    }
}
