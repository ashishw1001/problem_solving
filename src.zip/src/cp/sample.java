package cp;
import java.util.*;
import java.lang.*;
public class sample {
    public static void main (String[]args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        String num = sc.nextLine();
        String []strarr = str.split(",");
        String []numarr=num.split(",");
        for(int i=0;i<strarr.length;i++){
            String s=strarr[i];
            String n=numarr[i];

            String string="";
            String number="";
            for(int j=0;j<s.length();j++){
                if(Character.isLetter(s.charAt(j))){
                    string=string+s.charAt(j);
                }
                if(Character.isDigit(s.charAt(j))){
                    number=number+s.charAt(j);
                }
            }
            if(iscontain(numarr,number)){
                numarr[i]=string;
                strarr[i]=number;
            }
            else{
                numarr[i]="NA";
                strarr[i]="NA";
            }
        }
        String ansstring="";
        for(int i=0;i<strarr.length;i++){
            ansstring=ansstring+(strarr[i]+",");
        }
        String ansnumber="";
        for(int i=0;i<numarr.length;i++){
            ansnumber=ansnumber+(numarr[i]+",");
        }
        System.out.println(ansstring.substring(0,ansstring.length()-1));
        System.out.println(ansnumber.substring(0,ansnumber.length()-1));
    }
    public  static boolean iscontain(String [] numarr,String num){
        for(int i=0;i<numarr.length;i++){
            if(num.equals(numarr[i])) return  true;
        }
        return  false;
    }
}
