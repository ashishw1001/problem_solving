package cp;

import java.util.Scanner;

public class ashish1 {
    public  static  void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rows = scanner.nextInt();
        int num=scanner.nextInt();
        scanner.nextLine();
        int[][] arr = new int[rows][rows];
        String s="";
        for(int i=0;i<rows;i++){
            s=s+","+scanner.nextLine();
        }
        System.out.println(s.substring(1,s.length()));
    }
}
