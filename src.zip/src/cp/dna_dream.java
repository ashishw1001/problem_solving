package cp;
import java.util.Scanner;
public class dna_dream {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        int bond=0,k=0;
        for(int i=0;i<s.length();i++){
            int b=totalbonds(s.substring(0,i+1),s.substring(i+1,s.length()));
            if(b>bond){
                bond=b;
                k=i+1;
            }
        }
            System.out.println(k+" "+bond);
    }
    public  static int totalbonds(String s1,String s2){
         int n=0;
         int ans=0;
         if(s1.length()<s2.length()) n=s1.length();
         else n=s2.length();
         for(int i=0;i<n;i++){
             char c1=s1.charAt(s1.length()-i-1);
             char c2=s2.charAt(i);
             if(c1=='G'&&c2=='C'||c1=='C'&&c2=='G') ans++;
             if(c1=='A'&&c2=='T'||c1=='T'&&c2=='A') ans++;

         }
         return  ans;
    }
}
