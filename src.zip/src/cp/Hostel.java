package cp;

import com.sun.org.apache.bcel.internal.generic.ARETURN;

public class Hostel {
    String hostelName;
    public  Hostel(String hostelName){
        this.hostelName=hostelName;
    }
    public  int hotelFee(){
        return  25000;
    }

}
