package cp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class pronic_number {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        List<String> list=new ArrayList<>();
        for(int i=0;i<s.length();i++) {
            for (int j = i + 1; j < s.length(); j++) {
                list.add(s.substring(i, j ));
            }
        }
        for (String str:list){
            if(isproninc(str)){
                System.out.println(str);
            }
        }

    }
    public  static boolean isproninc(String str){
        if(str.charAt(0)=='0') return false;
        int n=Integer.parseInt(str);
        for(int i=1;i<=n;i++){
            if(i*(i-1)==n) return true;
        }
        return  false;
    }
}
