package cp;

import java.util.Scanner;
import java.util.*;

public class sumoffour {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line = "1,-1,0,0,2,-2";
        String[] carr = line.split(",");
        int n = 0;
        int count = 0;
        for (int i = 0; i < carr.length - 3; i++) {
            for (int j = i + 1; j < carr.length - 2; j++)
                for (int k = j + 1; k < carr.length - 1; k++) {
                    for (int l = k + 1; l < carr.length; l++) {
                        int a = Integer.parseInt(carr[i]);
                        int b = Integer.parseInt(carr[j]);
                        int c = Integer.parseInt(carr[k]);
                        int d = Integer.parseInt(carr[l]);
                        if ((a + b + c + d) == n) count++;

                    }
                }
        }
        System.out.println(count);
    }

}
