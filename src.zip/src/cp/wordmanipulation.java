package cp;

import java.util.Scanner;

public class wordmanipulation {
    public static void main(String[] args) {
        String s="i.like.this.program.very.much";
        String []sarr=s.split(".");
        String ans="";
        for(int i=sarr.length-1;i>=0;i--){
            ans=ans+"."+sarr[i];
        }
        System.out.println(ans.substring(1,ans.length()));
    }
  }
