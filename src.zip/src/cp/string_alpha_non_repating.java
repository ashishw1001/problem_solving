package cp;
import java.util.Scanner;
public class string_alpha_non_repating {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String line= sc.nextLine();
        System.out.println(longestUniqueSubsttr(line));
    }
    public static Boolean areDistinct(String str, int i, int j) {
        boolean[] visited = new boolean[26];
        for(int k = i; k <= j; k++)
        {
            if (visited[str.charAt(k) - 'A'] == true)
                return false;
            visited[str.charAt(k) - 'A'] = true;
        }
        return true;
    }
    public static int longestUniqueSubsttr(String str)
    {
        int n = str.length();
        int res = 0;
        for(int i = 0; i < n; i++)
            for(int j = i; j < n; j++)
                if (areDistinct(str, i, j))
                    res = Math.max(res, j - i + 1);
        return res;
    }
}

