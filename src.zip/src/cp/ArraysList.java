package cp;

public class ArraysList<T> {
}
