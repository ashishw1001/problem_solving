package cp;

public class perffect_square {
    public static void main(String[] args) {

    }
}
