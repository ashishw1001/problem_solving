package cp;

import java.util.Arrays;
import java.util.Scanner;

public class stringrot {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String line=sc.nextLine();
        String [] strr=line.split(",");

        for(int i=0;i<strr.length;i++) {
            String[] sub = strr[i].split(":");
            String s = sub[0];
            char[] carr = s.toCharArray();
            String s2 = sub[1];
            int sum = 0;
            for (int j = 0; j < s2.length(); j++) {
                int n = s2.charAt(j) - 48;
                sum = sum + n * n;
            }
            if (sum % 2 == 0) {
               rotateright(carr);
            } else {
                rorateleft(carr);
                rorateleft(carr);
            }
            System.out.println(new String(carr));
        }
    }
    public static void rotateright(char []carr){
        char prev = carr[carr.length - 1];
        char curr = 'c';
        for (int j = 0; j < carr.length; j++) {
            curr = carr[j];
            carr[j] = prev;
            prev = curr;
        }
        carr[0] = prev;
    }
    public static void rorateleft(char []carr){
        char prev=carr[carr.length-1];
        char curr='c';
        for(int j=carr.length-1;j>=0;j--){
            curr=carr[j];
            carr[j]=prev;
            prev=curr;
        }
        carr[carr.length-1]=prev;
    }
}
