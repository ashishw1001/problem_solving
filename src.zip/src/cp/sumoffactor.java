package cp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class sumoffactor {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of List ");
        int n=sc.nextInt();
        int []arr=new int[n];
        List<Integer> list=new ArrayList<>();
        for(int i=0;i<n;i++){
                arr[i]= sc.nextInt();
        }
        for(int val:arr){
               List<Integer> l=new ArrayList<>();
               if(val>0) l.add(1);
               for(int i=2;i<=val/2;i++) {
                   if (val % i == 0) {
                       l.add(i);
                   }
               }
               int sum=0;
               for(int ele:l) sum=sum+ele;
               for(int e:arr){
                   if(sum==e) list.add(sum);
               }
        }
        if(list.isEmpty()==true) System.out.println(-1);
        else {
            for (int e : list) {
                System.out.println(e);
            }
        }

    }
}
