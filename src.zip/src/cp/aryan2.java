package cp;

import java.util.Scanner;

public class aryan2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String line=sc.nextLine();
        int numarr1=sc.nextInt();
        int numarr2=sc.nextInt();
        String []strarr=line.split(",");
        int []cstr=new int[strarr.length];
        for(int i=0;i<strarr.length;i++){
            cstr[i]=repcount(strarr[i]);
        }
        String finalstr="";
        for(int i=1;i<strarr.length;i++){
            int num1=cstr[i-1];
            int num2=strarr[i].length();
            int p=num1%num2;
            finalstr=finalstr+strarr[i].charAt(p);

        }
        int ans=0;
        ans=ans+countSubStr(finalstr,numarr1);
        ans=ans+countSubStr(finalstr,numarr2);
        System.out.println(ans);
    }
    public  static  int repcount(String s){
        int ans=Integer.MIN_VALUE;
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            int sum=0;
            for(int j=0;j<s.length();j++){
                if(c==s.charAt(j)) sum++;
            }
            if(sum>ans) ans=sum;
         }
        return  ans;
    }
    static int countSubStr(String str, int n)
    {
        int len = str.length();
        return (len - n + 1);
    }
}
