package cp;

public class matdivbysum {
    public static void main(String[] args) {
        int [][]mat={{40,42,2},{30,24,27},{180,190,40},{11,121,13}};
        for(int i=0;i<mat.length;i++) {
            for (int j = 0; j < mat[0].length; j++) {
                if (ismat(i, j, mat)) {
                    showmat(i, j, mat);
                }
            }
        }
    }
    public  static boolean ismat(int i,int j,int[][]mat){
        if(i<mat.length-1&&j<mat[0].length-1){
            return isvalid(mat[i][j])&&isvalid(mat[i+1][j])&&isvalid(mat[i][j+1])&&isvalid(mat[i+1][j+1]);
        }
        return false;
    }
    public  static boolean showmat(int i,int j,int[][]mat){
        if(i<mat.length-1&&j<mat[0].length-1){
            System.out.println(mat[i][j]+" "+mat[i][j+1]);
            System.out.println(mat[i+1][j]+" "+mat[i+1][j+1]);
        }
        return false;
    }
    public  static boolean isvalid(int n){
        String s=Integer.toString(n);
        int c=0;
        for (int i=0;i<s.length();i++){
            c=c+s.charAt(i)-'0';
        }
        return n%c==0;
    }
}
