package cp;

import java.util.Arrays;
import java.util.Scanner;

public class poonam1{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        String volstr="";
        String  constr="";
         for(int i=0;i<str.length();i++){
             char c=str.charAt(i);
             if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'){
                 volstr=volstr+c;
             }
             else{
                 constr=constr+c;
             }
         }
         String vstr=sortString(volstr);
         String cstr=sortString(constr);
         String ans="";
         char v=' ';
         if(vstr.length()!=0){
              v=vstr.charAt(0);
         }
         char c=' ';
        if(cstr.length()!=0) {
             c = cstr.charAt(cstr.length() - 1);
        }
         int ansv=-1;
         int ansc=-1;
         for(int i=0;i<str.length();i++){
             if(str.charAt(i)==v){
                 ansv=i;
                 break;
             }
         }
        for(int i=str.length()-1;i>0;i--){
            if(str.charAt(i)==c){
                ansc=i;
                break;
            }
        }
        if(vstr.length()==0) vstr="NA";
        if(cstr.length()==0) cstr="NA";
        ans=vstr+(ansv)+cstr+(ansc);
        System.out.println(ans);
    }
    public  static String sortString(String str) {
        char []arr = str.toCharArray();
        Arrays.sort(arr);
        return (String.valueOf(arr));
    }
}
