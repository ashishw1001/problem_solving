package dsa_sheet;

import java.util.Scanner;
public class beautifulno{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        while (n-- > 0) {
            int num = sc.nextInt();
            int digit = sc.nextInt();
            while (num-- > 0) {
                int ele = sc.nextInt();
                if(isbeutiful(ele,digit)) System.out.println("Yes");
                else System.out.println("No");
            }
        }
    }
    public  static  boolean isbeutiful(int num,int digit){
        if(Integer.toString(num).contains(""+digit))return true;
        if(Integer.toString(num-digit).contains(""+digit))return true;
        return false;
    }
}
