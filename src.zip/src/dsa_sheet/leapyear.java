package dsa_sheet;
import java.util.Scanner;
public class leapyear {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int i=0;i<n;i++){
            int year=0;
            try {
                year = sc.nextInt();
            }
            catch (Exception e){
                System.out.println("INVALID YEAR");
                continue;
            }
            if (year % 4 == 0 && year % 100 != 0) {
                System.out.println("LEAP YEAR");
            } else if (year % 400 == 0) {
                System.out.println("LEAP YEAR");
            } else {
                System.out.println("NOT LEAP YEAR");
            }
        }
    }
}
