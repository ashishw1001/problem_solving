package dsa_sheet;

import java.util.Scanner;
public class geometric_progression {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int r=sc.nextInt();
        int n=sc.nextInt();
        int ans=a;
        for(int i=1;i<n;i++){
            a=a*r;
            ans+=a;
        }
        System.out.println(ans);
    }
}
