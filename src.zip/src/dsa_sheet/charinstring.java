package dsa_sheet;

import java.util.Scanner;
public class charinstring {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String innl=sc.nextLine();
        String finl=sc.nextLine();
        int []arr=new int[26];
        for(char c:finl.toCharArray())arr[c-'a']++;
        for(char c:innl.toCharArray()){
            if(c=='-')continue;
            arr[c-'a']--;
        }
        for(int i=0;i<26;i++){
            if(arr[i]>0) {
                for(int j=0;j<arr[i];j++)System.out.print((char)('a'+i));
            }
        }
    }
}
