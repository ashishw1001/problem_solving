package dsa_sheet;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class RSA {
    public static void main(String args[])
    {
        int p, q, n, z, d = 0, e, i;

        // The number to be encrypted and decrypted
        int msg = 12;
        double encrypted;
        BigInteger decrypted;

        // 1st prime number p
        p = 7;

        // 2nd prime number q
        q = 17;
        n = p * q;
        z = (p - 1) * (q - 1);
        System.out.println("the value of z = " + z);

        for (e = 2; e <= z; e++) {
            if (gcd(e, z) == 1) {
                break;
            }
        }
        System.out.println("the value of e = " + e);
        for (i = 0; i <= 9; i++) {
            int x = 1 + (i * z);

            // d is for private key exponent
            if (x % e == 0) {
                d = x / e;
                break;
            }
        }
        System.out.println("the value of d = " + d);
        encrypted = Math.pow(msg, e)%n;
        System.out.println("Encrypted message is : " + encrypted);

        // converting int value of n to BigInteger
        BigInteger N = BigInteger.valueOf(n);

        // converting float value of c to BigInteger
        BigInteger C = BigDecimal.valueOf(encrypted).toBigInteger();
        decrypted = (C.pow(d)).mod(N);
        System.out.println("Decrypted message is : " + decrypted);
    }

    static int gcd(int e, int z)
    {
        if (e == 0)
            return z;
        else
            return gcd(z % e, e);
    }
}
