package dsa_sheet;

import java.util.Scanner;
public class setting_arrgement {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int m=sc.nextInt();
        int n=sc.nextInt();
        int[][]matrix=new int[m][n];
        for(int i=0;i<matrix.length;i++){
            for(int j=0;j<matrix[0].length;j++){
                 int ele=sc.nextInt();
                  matrix[i][j]=ele;
            }
        }
        int ans=0;
        for(int i=0;i<matrix.length;i++){
            for(int j=0;j<matrix[0].length;j++){
               if(matrix[i][j]==1 && istalk(i,j,matrix))ans++;
            }
        }
        System.out.println(ans);
    }
    public  static boolean istalk(int i,int j,int [][]matrix){
        if(i>0&&matrix[i-1][j]==1)return  true;
        if(j>0 && matrix[i][j-1]==1)return true;
        if(i<matrix.length-1&&matrix[i+1][j]==1)return true;
        if(j<matrix[0].length-1&&matrix[i][j+1]==1)return true;
        return false;
    }
}
