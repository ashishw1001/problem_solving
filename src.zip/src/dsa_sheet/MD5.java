package dsa_sheet;

import java.math.BigInteger;
import java.security.*;
public class MD5{
    public static String getMd5(String input)
    {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            BigInteger no = new BigInteger(1, md.digest(input.getBytes()));
            return no.toString(16);
        }
        catch (NoSuchAlgorithmException e) {
            return " ";
        }
    }
    public static void main(String args[]) throws NoSuchAlgorithmException
    {
        String s = "Hello Message Digist";
        System.out.println("Encrypted msg : "+getMd5(s));
    }
}
