package dsa_sheet;
import java.util.Scanner;
public class automatic_vending_machine {
    public static void main(String[] args) {
             Scanner sc=new Scanner(System.in);
            String c[]={"Espresso Coffee","Cappuccino Coffee","Latte Coffee"};
            String t[]={"Plain Tea","Assam Tea","Ginger Tea","Cardamom Tea","Masala Tea","Lemon Tea","Green Tea","Organic Darjeeling Tea"};
            String s[]={"Hot and Sour Soup","Veg Corn Soup","Tomato Soup","Spicy Tomato Soup"};
            String b[]={"Hot Chocolate Drink","Badam Drink","Badam-Pista Drink"};
            String str="Welcome to CCD!\nEnjoy your ";
            char ch=sc.next().charAt(0);
            int  item=sc.nextInt();
            int i;
            if(ch=='c')
            { for(i=0; i<3; i++) {
                    if(item==i+1) {
                        System.out.println("Welcome to CCD!\nEnjoy your "+c[i]+"!");
                        break;
                    }
                }
                if(i==3) {
                    System.out.println("INVALID OPTION!");
                }
            }
            else if(ch=='t')
            { for(i=0; i<8; i++) {
                    if(item==i+1) {
                        System.out.println("Welcome to CCD!\nEnjoy your "+t[i]+"!");
                        break;
                    }
              }
                if(i==8) {
                    System.out.println("INVALID OPTION!");
                }
            }
            else if(ch=='s')
            { for(i=0; i<4; i++)
                { if(item==i+1)
                    {  System.out.println("Welcome to CCD!\nEnjoy your "+s[i]+"!");
                        break;
                    }
                }
                if(i==4) {
                    System.out.println("INVALID OPTION!");
                }
            }
            else if(ch=='b')
            { for(i=0; i<3; i++) {
                    if(item==i+1) {
                        System.out.println("Welcome to CCD!\nEnjoy your "+c[i]+"!");
                        break;
                    } }
                if(i==3) {
                    System.out.println("INVALID OPTION!");
                }
            }
            else
            {
                System.out.println("INVALID INPUT!");
            }
            return;
    }
}

