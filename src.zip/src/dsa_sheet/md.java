package dsa_sheet;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
public class md {
    public static String getMd5(String input)
    {
        try{
            MessageDigest md=MessageDigest.getInstance("MD5");
            BigInteger no=new BigInteger(1,md.digest(input.getBytes()));
            return no.toString(16);

        }
        catch(NoSuchAlgorithmException e){
            return "Algorithm not found ";
        }
    }
    public static void main(String[] args) {
        String s="Geeks for Geeks";
        System.out.println(getMd5(s));
    }
}
