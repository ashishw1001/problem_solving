package dsa_sheet;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class armstrongno {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int l=sc.nextInt();
        int u=sc.nextInt();
        List<Integer>list=new ArrayList<>();
        while(l<=u){
            if(isvalid(l))list.add(l);
            l++;
        }
        if(list.size()>0) System.out.println(1);
        else System.out.println(-1);
        for(int i:list) System.out.println(i);
    }
    public static boolean isvalid(int n){
        String s=Integer.toString(n);
        int length=s.length();
        int sum=0;
        for(int i=0;i<s.length();i++){
            sum+=Math.pow((s.charAt(i)-'0'),length);
        }
        return sum==n;
    }
}
