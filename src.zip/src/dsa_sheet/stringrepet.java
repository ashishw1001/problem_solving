package dsa_sheet;

import java.util.Scanner;

public class stringrepet {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        int n=sc.nextInt();
        int r=n/s.length();
        while(r>0){
            s=s+s;
            r--;
        }
        s=s.substring(0,n);
        int ans=0;
        for(char c:s.toCharArray())if(c=='a')ans++;
        System.out.println(ans);

    }
}
