package collcetions;

import java.util.Arrays;
import java.util.Scanner;

public class quicksort {
    public  static void quick(int arr[],int left,int right){
         if(left<right) {
             int p = partesion(arr, left, right);
             quick(arr, left, p);
             quick(arr, p + 1, right);
         }
    }
    public  static int partesion(int []arr,int left,int right){
        int ele=arr[left];
        int p=left;
        left++;
        while(left!=right){
            if(arr[left]<ele){
                arr[p]=arr[left];
                arr[left]=arr[p+1];
                arr[p+1]=ele;
                p++;
            }
            left++;
       }
        return  p;


    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int []arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        quick(arr,0,arr.length);
        for(int i:arr){
            System.out.print(i+" ");
        }
    }
}
