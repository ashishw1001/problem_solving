package collcetions;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class lexostringopration {
    public static List<String>list=new ArrayList<>();
    public static int n;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
        sc.nextLine();
        String s=sc.nextLine();
        moves(s,"","");
        for(String s1:list){
            if(s.compareTo(s1)>0)s=s1;
        }
        System.out.println(list);
        System.out.println(s);
    }
    public  static void moves(String s,String ben,String kevin){
        System.out.println(kevin);
        if(kevin.length()==n)list.add(kevin);
        if(s.length()>0)moves(s.substring(0,s.length()-1),ben+s.charAt(0),kevin);
        if(ben.length()>0)moves(s,ben.substring(1),kevin+ben.charAt(0));
    }
}
