package collcetions;

import java.util.Arrays;
import java.util.Scanner;
import java.util.function.IntToDoubleFunction;

public class slection_sort {
    public  static void selectionsort(int []arr){
        for(int i=0;i<arr.length;i++){
            int minindex=i;
            int ele=Integer.MAX_VALUE;
            int index=i;
            for(int j=minindex;j<arr.length;j++){
                if(arr[j]<ele){
                    ele=arr[j];
                    index=j;
                }
            }
            int temp=arr[i];
            arr[i]=ele;
            arr[index]=temp;
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int []arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        selectionsort(arr);
        Arrays.sort(arr);
        for(int i:arr){
            System.out.print(i+" ");
        }

    }
}
