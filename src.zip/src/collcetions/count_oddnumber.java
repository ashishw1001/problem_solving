package collcetions;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class count_oddnumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        String strans="";
        String num="";
        List<Integer> list=new ArrayList<>();
        for(char c: s.toCharArray()){
            if(Character.isAlphabetic(c)){
                strans=strans+c;
                if(num.length()>0&&Integer.parseInt(num)%2!=0){
                    list.add(Integer.parseInt(num));
                }
                num="";
            }
            else{
                num=num+c;

            }
        }
        if(list.size()==0) System.out.println("Numbers: None");
        else {
            System.out.print("Numbers:");
            System.out.println(list);
        }
        System.out.println();
        System.out.println("String:"+strans);
    }
}
