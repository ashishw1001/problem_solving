package collcetions;

import java.util.Scanner;

public class sumeuqalcount {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        String []arr=s.split("=");
        String x=arr[0];
        String y=arr[1];
        int c=0;
        while(!x.equals(y)){
            int l=x.charAt(x.length()-1);
            int n=Integer.parseInt(x.substring(0,x.length()-1));
            n=n+(l-'0');
            x=Integer.toString(n);
            c++;
        }
        System.out.println(c);
    }

}
