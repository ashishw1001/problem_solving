package collcetions;
import java.util.*;
public class g{
    private static int V;
    private static LinkedList<Integer> adj[];
    public static void g(int v){
        V=v;
        adj=new LinkedList[v];
        for(int i=0;i<v;i++)
            adj[i]=new LinkedList<Integer>();
    }
    public  void addEdge(int v,int e){
        adj[v].add(e);
    }
    public static void BFS(int s){
        boolean visited[]=new boolean[V];
        LinkedList<Integer> queue=new LinkedList<>();
        visited[s]=true;
        queue.add(s);
        while(!queue.isEmpty()){
            s = queue.poll();
            System.out.print(s+" ");
            Iterator<Integer> i=adj[s].listIterator();
            while (i.hasNext()) {
                int n = i.next();
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                }
            }
        }
    }
    public static void DFSutil(int s,boolean []visited){
          visited[s]=true;
          System.out.print(s+" ");
          Iterator<Integer>i=adj[s].listIterator();
          while (i.hasNext()){
              int n=i.next();
              if(!visited[n]){
                  DFSutil(n,visited);
              }
          }
    }
    public  static void DFS(int s){
        boolean visited[]=new boolean[V];
        DFSutil(s,visited);
    }



    public static void main(String[] args) {
        g ob=new g();
        g(4);
        ob.addEdge(0, 1);
        ob.addEdge(0, 2);
        ob.addEdge(1, 2);
        ob.addEdge(2, 0);
        ob.addEdge(2, 3);
        ob.addEdge(3, 3);
        BFS(2);
        System.out.println();
        DFS(2);
    }
}
