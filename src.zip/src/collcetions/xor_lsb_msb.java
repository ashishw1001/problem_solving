package collcetions;

import java.util.Scanner;

public class xor_lsb_msb {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        String s=Integer.toBinaryString(n);
        String x="";
        for(int i=1;i<s.length();i++){
            x=x+((s.charAt(i)-'0')^(s.charAt(i-1)-'0') );
        }
        x=x+((s.charAt(s.length()-1)-'0')^1);
        System.out.println(Integer.parseInt(x,2));
    }
}
