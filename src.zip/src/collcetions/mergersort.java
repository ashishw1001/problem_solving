package collcetions;

import java.util.Scanner;

public class mergersort {
    public static void merger(int arr[],int st,int m,int ed){
        int n1=m-st+1;
        int n2=ed-m;
        int L[]=new int[n1];
        int R[]=new int[n2];
        for(int i=0;i<n1;++i){
            L[i]=arr[st+i];
        }
        for(int j=0;j<n2;++j){
            R[j]=arr[m+j];
        }
        int i=0,j=0;
        int k=st;
        while(i<n1&&j<n2){
            if(L[i]>=R[j]){
                arr[k]=R[j];
                j++;
            }
            else {
                arr[k] = L[i];
                i++;
            }
            k++;
        }
        while(i<n1&&k<ed){
            arr[k]=L[i];
            k++;
            i++;
        }
        while(j<n2&&k<ed) {
            arr[k] = R[j];
            k++;
            j++;
        }
    }
    public static void  sort(int arr[],int st,int ed){
             if(st<ed){
                 int m=st+(ed-st)/2;
                 sort(arr,st,m);
                 sort(arr,m+1,ed);
                 merger(arr,st,m,ed);
             }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        sort(arr,0,arr.length);
        for(int i:arr){
            System.out.print(i+" ");
        }
    }
}
