package collcetions;

import java.util.Scanner;

public class insertionsort {
    public static void insert(int arr[]){
        for(int i=1;i<arr.length;i++){
            int key=arr[i];
            int ind=i-1;
            while(ind>=0&&arr[ind]>key){
                arr[ind+1]=arr[ind];
                ind--;
            }
            arr[ind+1]=key;
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int []arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        insert(arr);
        for(int i:arr){
            System.out.print(i+" ");
        }
    }
}
