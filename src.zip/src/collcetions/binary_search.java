package collcetions;

import java.util.Scanner;

public class binary_search {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        System.out.println("Enter element to search");
        int ele=sc.nextInt();
        System.out.println(binary(arr,0,arr.length-1,ele));

    }
    public  static  int binary(int []arr,int st,int ed,int ele){
        int mid=(st+ed)/2;
        if(ele==arr[mid]) return mid;
        if(arr[mid]>ele){
            return  binary(arr,st,mid-1,ele);
        }
        else {
            return binary(arr, mid + 1, ed, ele);
        }
    }
}
