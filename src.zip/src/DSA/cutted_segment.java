package DSA;

import java.util.*;

public class cutted_segment {
    static int getOccurrence(int n, int d)
    {
        int result = 0;
        int itr = d;
        while (itr <= n)
        {  if (itr % 10 == d)
                result++;
            if (itr != 0 && itr/10 == d)
            {
                result++;
                itr++;
            }
            else if (itr/10 == d-1)
                itr = itr + (10 - d);
            else
                itr = itr + 10;
        }
        return result;
    }


    // Driver code
    public static void main (String[] args)
    {
        int n = 20, d = 2;

        System.out.println(getOccurrence(n, d) );
    }
}
