package DSA;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.Math.*;
public class UserMainCode {
    public static int[] arrage(int input1, int[] input2) {
        List<Integer> even = new ArrayList<Integer>();
        List<Integer> odd = new ArrayList<Integer>();
        Arrays.sort(input2);
        if ((input2[0] % 2 == 0)) {
            Arrays.sort(input2);
            for (int i : input2) {
                if (i % 2 == 0) even.add(i);
                else odd.add(i);
            }
            List<Integer> ans = new ArrayList<Integer>();
            while (even.size() > 0 || odd.size() > 0) {
                if (even.size() > 0) {
                    ans.add(even.get(0));
                    even.remove(even.get(0));
                }
                if (odd.size() > 0) {
                    ans.add(odd.get(0));
                    odd.remove(odd.get(0));
                }
            }
            int result[] = new int[ans.size()];
            for (int i = 0; i < input2.length; i++) {
                result[i] = ans.get(i);
            }
            return result;
        }
        else
        {
            Arrays.sort(input2);
            for (int i : input2)
            {
                if (i % 2 == 0) even.add(i);
                else odd.add(i);
            }
            List<Integer> ans = new ArrayList<>();
            while (even.size() > 0 || odd.size() > 0) {
                if (odd.size() > 0) {
                    ans.add(odd.get(0));
                    odd.remove(odd.get(0));
                }
                if (even.size() > 0) {
                    ans.add(even.get(0));
                    even.remove(even.get(0));
                }
            }
            int result[] = new int[ans.size()];
            for (int i = 0; i < input2.length; i++) result[i] = ans.get(i);
            return result;
        }
    }


    public static void main(String[] args) {
       int [] arr={9,12,23,8,5};
        //int [] arr={47,49,36,98,90};

        int ans[]= arrage(5,arr);
        for(int i:ans) System.out.print(i+" ");
    }
}
