package DSA;
import java.util.*;
public class hehe {
    public static List<Integer>ans=new ArrayList<>();
    public static int tocheck;
    public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            int n=sc.nextInt();
            tocheck=sc.nextInt();
            int []arr=new int[n];
            for(int i=2;i<(2+n);i++)arr[i-2]=i;
            Collections.sort(ans);
            if(ans.size()==0) System.out.println(-1);
            else System.out.println(ans.get(0));
    }
    static void printSubArrays(int[] arr, int start, int end)
    { 
        if (end == arr.length)
            return;

        else if (start > end)
            printSubArrays(arr, 0, end + 1);
        else {
            List<Integer>list=new ArrayList<>();
            for (int i = start; i < end; i++)
                list.add(arr[i]);
            list.add(arr[end]);
            if(check(list)){
                ans.add(list.size());
            }
            printSubArrays(arr, start + 1, end);
        }
        return;
    }
    public static boolean check(List<Integer>list){
        int s=0;
        for(int i:list)s+=i;
        return s-list.size()==tocheck;
    }
}

