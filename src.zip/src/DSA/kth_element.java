package DSA;

import java.util.*;
public class kth_element{
    public  static  List<Integer>list=new ArrayList<>();
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int []arr=new int[n];
        for(int i=0;i<n;i++)arr[i]=sc.nextInt();
        sumSubarrayMins(arr);
        int q=sc.nextInt();
        Collections.sort(list);
        int i=0;
        System.out.println(list);
        while(i<q){
            System.out.println(list.get(sc.nextInt()-1));
            i++;
        } }

//    static void SubArrays(int[] arr, int start, int end)
//    {
//        if (end == arr.length) return;
//        else if (start > end)
//            SubArrays(arr, 0, end + 1);
//        else {
//            int min=Integer.MAX_VALUE;
//            for (int i = start; i <=end; i++)if((arr[i]<min))min=arr[i];
//            list.add(min);
//            SubArrays(arr, start + 1, end);
//        }
//        return;
//    }
    public static void sumSubarrayMins(int[] arr) {
        int MODULO = (int) Math.pow(10, 9) + 7;
        int n = arr.length;
        Stack<Integer> incStack = new Stack<>();
        int[] dp = new int[n];
        for (int i = n - 1; i >= 0; i--) {
            while (!incStack.isEmpty() && arr[incStack.peek()] >= arr[i]) {
                incStack.pop();
            }
            if (!incStack.isEmpty()) {
                dp[i] = (dp[i] + dp[incStack.peek()] + arr[i] * (incStack.peek() - i)) % MODULO;
            } else {
                dp[i] = (dp[i] + arr[i] * (n - i)) % MODULO;
            }
            incStack.push(i);
        }

        for (int d : dp) {
           list.add(d);
        }

    }
}
