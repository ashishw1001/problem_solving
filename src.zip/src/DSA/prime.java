package DSA;

public class prime {
    public static void main(String[] args) {
        int []arr=new int[101];
        for(int i=0;i<101;i++)arr[i]=i;
        boolean [] boolarr=new boolean[101];
        boolarr[0]=true;
        boolarr[1]=true;
        for(int i=2;i<=Math.sqrt(100);i++){
            if(!boolarr[i]&&isprime(i)){
                for(int j=i+i;j<=boolarr.length;j=j+i){
                    if(arr[j]%i==0)boolarr[j]=true;
                }
            }
        }
        for(int i=59;i<101;i++){
            if(!boolarr[i]) System.out.print(arr[i]+" ");
        }

    }
    public static  boolean isprime(int n){
        for(int i=2;i<Math.sqrt(n);i++){
            if(n%i==0)return false;
        }
        return true;
    }

}
