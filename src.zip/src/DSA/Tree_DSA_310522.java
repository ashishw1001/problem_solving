package DSA;

//  Binary Tree - Runtime User Input

import java.util.*;

class Node
{
    Node left, right;
    int data;

    public Node (int data)
    {
        this.data=data;
    }
}

public class Tree_DSA_310522
{
    static Scanner op = null;

    //  sum of all elements in the tree.........
    public int op1(Node node)
    {
        if(node == null)
        {
            return 0;
        }

        return node.data + op1(node.left) + op1(node.right);
    }




    // Difference of values at even & odd level
    public int op2(Node node)
    {
        if(node == null)
        {
            return 0;
        }

        return node.data - op2(node.left) - op2(node.right);
    }




    // Number of nodes in a tree.
    public int op3(Node node)
    {
        if(node == null)
        {
            return 0;
        }

        return 1 + op3(node.left) + op3(node.right);
    }




    // number of leaf node in a tree
    public int op4(Node node)
    {
        if(node == null)
        {
            return 0;
        }

        if(node.left == null && node.right == null)
        {
            return 1;
        }

        return op4(node.left) + op4(node.right);
    }



    public static void main(String[] args)
    {
        op = new Scanner(System.in);

        Tree_DSA_310522 op5=new Tree_DSA_310522();   //   sum of all elements in the tree.........

        Tree_DSA_310522 op6=new Tree_DSA_310522();   //   Difference of values at even & odd level

        Tree_DSA_310522 op7=new Tree_DSA_310522();   //   Number of nodes in a tree.

        Tree_DSA_310522 op8=new Tree_DSA_310522();   //   number of leaf nodes in a tree

        Node root = createTree();

        inOrder(root);
        System.out.println(" :  In-Order");

        preOrder(root);
        System.out.println(" :  Pre-Order");

        postOrder(root);
        System.out.println(" :  Post-Order");

        // sum of all elements in the tree.
        System.out.println("Sum of all elements in the given Tree is :" + op5.op1(root));

        // Difference of values at even & odd level.
        System.out.println("Difference of values at even & odd level :" + op6.op2(root));

        // Number of nodes in a tree.
        System.out.println("Number of nodes in a tree. :" + op7.op3(root));

        // number of leaf nodes in a tree.
        System.out.println("Number of leaf nodes in a tree. :" + op8.op4(root));

    }

    static Node createTree()
    {
        Node root = null;

        System.out.println("Enter data : ");
        int data = op.nextInt();

        if (data == -1) return null;

        root = new Node(data);

        System.out.println("Enter left for " + data);
        root.left = createTree();

        System.out.println("Enter right for " + data);
        root.right = createTree();

        return root;
    }

    static void inOrder(Node root)
    {
        if(root == null) return;

        inOrder(root.left);
        System.out.print(root.data+" ");
        inOrder(root.right);
    }

    static void preOrder(Node root)
    {
        if(root == null) return;

        System.out.print(root.data+" ");
        preOrder(root.left);
        preOrder(root.right);
    }

    static void postOrder(Node root)
    {
        if(root == null) return;

        postOrder(root.left);
        postOrder(root.right);
        System.out.print(root.data+" ");
    }
}