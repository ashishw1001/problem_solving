package DSA;
import java.util.*;
public class sortarray_with_frequncy {
    public static void main(String[] args) {
        int []arr={10,7,11,10,10,7,5,6};
        HashMap<Integer,Integer> map=new HashMap<>();
        for(int i:arr){
            if(map.containsKey(i)){
                map.put(i,map.get(i)+1);
            }
            else map.put(i,1);
        }
        int max=Integer.MIN_VALUE;
        for(Map.Entry<Integer,Integer> me :map.entrySet()){
            if(me.getValue()>max){
               max=me.getValue();
            }
        }
        List<Integer> ans=new ArrayList<>();
        while(max>0){
            List<Integer> temp=new ArrayList<>();
            for(Map.Entry<Integer,Integer> me :map.entrySet()){
                if(me.getValue()==max){
                    for(int k=0;k<max;k++)temp.add(me.getKey());

                }
            }
            Collections.sort(temp);
            for(int i=0;i<temp.size();i++){
                ans.add(temp.get(i));
            }
            max--;
        }
        for(int i:ans){
            System.out.print(i+" ");
        }
    }
}
