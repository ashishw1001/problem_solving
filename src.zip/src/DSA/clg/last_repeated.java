package DSA.clg;

import java.util.HashMap;

public class last_repeated {
    public static void main(String[] args) {
        int []arr={3,7,5,7,8,4,5,3};
        boolean flag=true;
        HashMap<Integer,Integer>map=new HashMap<>();
        for(int i:arr){
            if(map.containsKey(i)){
                System.out.println(i);
                break;
            }
            else map.put(i,1);
        }

    }
}
