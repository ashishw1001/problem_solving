package DSA.clg;
import java.lang.*;
class Bus implements Runnable{
    int available=10;
    int seat;
    Bus(int seat)
    {
        this.seat=seat;
    }
    public synchronized void run()
    {
        String name=Thread.currentThread().getName();
        if(available>=seat)
        {
            System.out.println("Hello Passenger , Your seat is booked. Thank you for booking");
            available=available-seat;
        }
        else
        {
            System.out.println("Sorry Dear Passenger seat is not available");
        }
    }
}
public class syncro {
    public static void main(String args[]) throws Exception{
        Bus b1=new Bus(2);
        Thread t1=new Thread(b1);
        Thread t2=new Thread(b1);
        Thread t3=new Thread(b1);
        Thread t4=new Thread(b1);
        Thread t5=new Thread(b1);
        Thread t6=new Thread(b1);
        Thread t7=new Thread(b1);

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();

    }
}

