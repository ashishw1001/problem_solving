package codevita;

import java.util.*;

public class sanke_and_ladder{

}
