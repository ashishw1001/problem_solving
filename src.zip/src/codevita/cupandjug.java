package codevita;

import java.util.Scanner;

public class cupandjug {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
    }
}
